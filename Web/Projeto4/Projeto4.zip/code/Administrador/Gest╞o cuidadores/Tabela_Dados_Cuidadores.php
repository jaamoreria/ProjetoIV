<div class="box-body" id="dados">
  <table id="example1" class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>Nome</th>
        <th>Username</th>
        <th>Email</th>
        <th>Telemóvel</th>
        <th>Data de Admissão</th>
        <th style="text-align:right;">Opções</th>
      </tr>
    </thead>

    <?php include ("Obter_Cuidadores.php"); ?>
  </table>
</div>
